#include "file1.hpp"
// ZTEST_F(q_qwq, qwqq) {
//   EXPECT_EQ(1, q());
//   return ZState::z_success;
// }
