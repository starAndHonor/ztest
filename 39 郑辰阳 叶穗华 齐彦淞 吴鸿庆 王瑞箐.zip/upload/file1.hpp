/*
 * @Author: starAndHonor 13750616920@163.com
 * @Date: 2025-05-21 19:33:48
 * @LastEditors: starAndHonor 13750616920@163.com
 * @LastEditTime: 2025-06-06 11:42:59
 * @FilePath: /ztest/file1.hpp
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置
 * 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */

#pragma once
#include "ztest/gui.hpp"
// int q() { return 1; }
// ZTEST_F(q_qwq, qwq) {
//   EXPECT_EQ(6, 6);
//   return ZState::z_success;
// }
