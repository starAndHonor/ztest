
#pragma once
#include "ztest_base.hpp"
#include "ztest_utils.hpp"
#include <any>
#include <exception>
#include <functional>
template <typename InputType, typename OutputType> class ZTestDataManager {

public:
  using Input = InputType;
  using Output = OutputType;
  ZTestDataManager(initializer_list<pair<Input, Output>> cases)
      : _data(cases) {}

  auto current() const { return _data[_index]; }
  bool has_next() const { return _index < _data.size(); }
  void next() { ++_index; }
  void reset() { _index = 0; }

private:
  vector<pair<Input, Output>> _data;
  size_t _index = 0;
};
// template <typename Input, typename Output>
// class ZTestCSVDataManager : public ZTestDataManager<Input, Output> {
// public:
//   ZTestCSVDataManager(const std::string &filename)
//       : ZTestDataManager<Input, Output>({}) {
//     loadFromCSV(filename);
//   }

//   const std::vector<std::pair<Input, Output>> &getTestCases() const override
//   {
//     return this->_data;
//   }

// private:
//   void loadFromCSV(const std::string &filename) {
//     CSVStream csv(filename);
//     std::vector<std::vector<CSVCell>> csvData;
//     csv >> csvData;

//     for (const auto &row : csvData) {
//       if (row.size() < 2) {
//         throw std::runtime_error(
//             "CSV row must contain at least 2 elements (input and output)");
//       }

//       // Convert first element to Input type
//       Input input = convertVariant<Input>(row[0]);

//       // Convert second element to Output type
//       Output output = convertVariant<Output>(row[1]);

//       this->_data.emplace_back(input, output);
//     }
//   }

//   template <typename T> T convertVariant(const CSVCell &cell) {
//     try {
//       if constexpr (std::is_same_v<T, int>) {
//         if (std::holds_alternative<int>(cell)) {
//           return std::get<int>(cell);
//         }
//         throw std::runtime_error("Cannot convert variant to int");
//       } else if constexpr (std::is_same_v<T, double>) {
//         if (std::holds_alternative<double>(cell)) {
//           return std::get<double>(cell);
//         }
//         throw std::runtime_error("Cannot convert variant to double");
//       } else if constexpr (std::is_same_v<T, std::string>) {
//         if (std::holds_alternative<std::string>(cell)) {
//           return std::get<std::string>(cell);
//         }
//         throw std::runtime_error("Cannot convert variant to string");
//       } else {
//         throw std::runtime_error("Unsupported type conversion");
//       }
//     } catch (const std::bad_variant_access &) {
//       throw std::runtime_error("Variant conversion failed");
//     }
//   }
// };
template <typename Input, typename Output>
class ZTestParameterized : public ZTestBase {
protected:
  ZTestDataManager<Input, Output> &_data;

public:
  ZTestParameterized(const string &name, ZType type, const string &desc,
                     ZTestDataManager<Input, Output> &data)
      : ZTestBase(name, type, desc), _data(data) {}

  ZState run() override {
    _data.reset();
    while (_data.has_next()) {
      if (run_single_case() != ZState::z_success)
        return ZState::z_failed;
      _data.next();
    }
    return ZState::z_success;
  }

  virtual ZState run_single_case() = 0;
};
